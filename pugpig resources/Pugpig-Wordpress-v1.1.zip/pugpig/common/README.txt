Generic helper functions for writing a PHP Pugpig plugin.
If you are wring a plugin for a PHP based CMS please get in touch.