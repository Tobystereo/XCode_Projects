<credentials>
	<userid>150edee7582351cd0a37b24f6be8969accb5f696</userid>
	<password>21cf2cf44c39242699fba373d674c5cd1b4342d7</password>
	<subscription state="active"/>
	<!--
	URL: THIS IS FAKE AND STATIC
	-->
</credentials>
