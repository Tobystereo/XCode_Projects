({
    baseUrl: ".",
    paths: {
        'modules': 'modules',
        templates: 'templates',
        jquery: 'lib/jquery-1.8.3.min',
        underscore: 'lib/lodash.min'
    },
    name: "main",
    out: "main.min.js"
})