define([
  'jquery',
  'plugins/jquery-colorbox.min'
], function( $ ) {

  var Lightbox = function() {};

  // var self = this,
  //     tag = clicked[ 0 ].tagName.toLowerCase(),
  //     gallery,
  //     figure,
  //     imgGroup,
  //     src;

  //   if ( tag === 'a' ) {
  //     figure = clicked.parents('figure');
  //     imgGroup = figure.data( 'image-group' );
  //     if ( imgGroup ) {
  //       log('gallery')
  //     } else {
  //       src = Utilities.rebaseUrl( figure.find('img').attr( 'src' ), this.visiblePage.attr( 'src' ) );
  //     }
  //   }

  //   $.colorbox({
  //     href: src,
  //     opacity: 1,
  //     maxWidth: '100%',
  //     maxHeight: '100%',
  //     title: figure.find('figcaption').text(),
  //     fixed: true,
  //     onOpen: function() {
  //       self.win.css({
  //         overflowY: 'hidden'
  //       });
  //     },
  //     onClosed: function() {
  //       self.win.css({
  //         overflowY: 'auto'
  //       });
  //     }
  //   });

  //   $('#cboxWrapper').on('click','img', $.colorbox.close );

});